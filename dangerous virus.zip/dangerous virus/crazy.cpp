#include <windows.h>
#include <mmsystem.h>
#include <math.h>

#pragma comment(lib, "winmm.lib")

typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE b;
        BYTE g;
        BYTE r;
        BYTE Reserved;
    };
} _RGBQUAD, *PRGBQUAD;

// --- WAV DOSYASI ÇALMA FONKSİYONU (D SÜRÜCÜSÜ) ---
DWORD WINAPI playWavThread(LPVOID lpParam) {
    // Doğrudan D sürücüsündeki belirttiğin yolu kullanıyoruz
    const char* wavPath = "D:\\dangerous virus\\track (1).wav";

    // SND_LOOP: Sürekli çal, SND_FILENAME: Dosya yolundan oku, SND_ASYNC: Arka planda çal
    PlaySoundA(wavPath, NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);
    
    return 0;
}

// --- GÖRSEL EFEKT (SHADER) ---
DWORD WINAPI shader4(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen; 
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h; 

    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, 0);
    SelectObject(hdcMem, hbmTemp);

    for (;;) {
        HDC hdcCurrent = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcCurrent, 0, 0, SRCCOPY);

        for (INT i = 0; i < w * h; i++) {
            rgbScreen[i].r = (rgbScreen[i].r * 2) % 255;
            rgbScreen[i].g = (rgbScreen[i].g * 2) % 255;
            rgbScreen[i].b = (rgbScreen[i].b * 2) % 255;
        }

        BitBlt(hdcCurrent, 0, 0, w, h, hdcMem, -30, 0, SRCCOPY);
        BitBlt(hdcCurrent, 0, 0, w, h, hdcMem, w - 30, 0, SRCCOPY);
        BitBlt(hdcCurrent, 0, 0, w, h, hdcMem, 0, -30, SRCCOPY);
        BitBlt(hdcCurrent, 0, 0, w, h, hdcMem, 0, h - 30, SRCCOPY);

        ReleaseDC(NULL, hdcCurrent);
        Sleep(10); 
    }
    return 0;
}

// --- MOUSE ERROR ---
DWORD WINAPI mouseError(LPVOID lpParam) {
    HICON hIcon = LoadIcon(NULL, IDI_ERROR); 
    POINT p;
    for (;;) {
        HDC hdc = GetDC(0);
        GetCursorPos(&p);
        DrawIcon(hdc, p.x + (rand() % 21 - 10), p.y + (rand() % 21 - 10), hIcon);
        ReleaseDC(0, hdc);
        Sleep(15);
    }
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd) {
    // MessageBox içeriği orijinal haliyle bırakıldı
    if (MessageBox(NULL, "Sesi ve GDI'yi baslatmak istiyor musun?", "Winlator Test", MB_YESNO | MB_ICONWARNING | MB_TOPMOST) == IDYES) {
        CreateThread(NULL, 0, playWavThread, NULL, 0, NULL);
        CreateThread(NULL, 0, shader4, NULL, 0, NULL);
        CreateThread(NULL, 0, mouseError, NULL, 0, NULL);
        while(TRUE) Sleep(1000);
    }
    return 0;
}
